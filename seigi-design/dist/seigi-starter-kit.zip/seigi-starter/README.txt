せいぎデザイン スターターキット
1. powerpoint/ の seigi-starter.pptx か seigi-basic.pptx を開く
2. ジグDRは seigi-jig-dr.pptx / seigi-jig-dr.xlsx
3. 色は変えなくてOK。文言だけ差し替える
4. 最新版は Box のせいぎデザインフォルダを参照
